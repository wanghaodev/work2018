-- 变化类型(1:课次变化,2:班级变化,3:学生变化,4:直播课变化,5:直播组（课程）变化,6:服务变化)
SELECT * FROM t_kooup_mq_chanage_notify mq WHERE mq.is_new_flag = 1 ORDER BY mq.create_time;
