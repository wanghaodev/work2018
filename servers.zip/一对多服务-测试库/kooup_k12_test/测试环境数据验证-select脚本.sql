SELECT * from t_kooup_product_info p where p.product_name  like '%小学语文直播产品@%' AND p.product_course_status =2 ;

SELECT * FROM t_sharks_exam_season s where  s.`name` like '%2018秋季%' AND s.product_line = 24;

SELECT * FROM t_sharks_product_line_def pl WHERE pl.`name` = '高中';

SELECT * FROM t_kooup_lesson_info l ;

SELECT * FROM t_kooup_mq_chanage_notify mq WHERE mq.is_new_flag =1;
-- 7168
SELECT * FROM t_kooup_live l WHERE l.product_code = 'P432594223418572800' AND l.live_code = 'PL432840206912061440';

SELECT * FROM t_kooup_lesson_info l WHERE l.live_code = 'PL432840206912061440';

SELECT * FROM t_kooup_classroom_lecturer t WHERE t.teacher_name  like '%hanyu46%';

SELECT * FROM t_account_validity a where a.product_id = '9117';

SELECT * FROM sys_user u where u.outer_user_id in(73652109,73652117,73652120);

SELECT * FROM t_kooup_class_student stu WHERE stu.user_code in('U432601624033099776','U432859688963407872','U432906551401906176');


