SELECT * FROM t_kooup_product_info p where p.product_code = 'P432594224190324736';

SELECT * FROM t_kooup_live l WHERE l.live_code = 'PL433002928597368832' AND l.live_num=5;

SELECT * FROM t_kooup_lesson_info l where l.live_code = 'PL433002928597368832';

-- PL433002928597368832	初一物理第4讲@韩余47 -- 4904	P432594224190324736				

SELECT * FROM t_sharks_exam_season s where s.id = '6';

SELECT * FROM t_kooup_classroom_lecturer cl where cl.work_account = 'hanyu46';
-- UT432582138907328512	anata026
-- UT432582344977678336	anata03
-- UT432585488033906688	hanyu47 （更新前）
-- UT432875041282064384	hanyu46  （更新后）

-- service_id:437
SELECT * FROM t_kooup_course_info c where c.service_id = '437';

SELECT * FROM t_kooup_product_info p WHERE p.product_code = 'P433290058473144320';

SELECT * FROM t_schedule_classroom c where c.id in(1861,1860);