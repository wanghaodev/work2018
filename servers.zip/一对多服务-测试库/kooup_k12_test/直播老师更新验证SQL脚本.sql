SELECT * FROM t_sharks_live l where l.`name` like  '%爽快的直播课4%';
SELECT * FROM t_kooup_live l WHERE l.id = '7150';
-- 7150
SELECT * FROM t_sharks_live_teacher lt WHERE lt.live_id = '7150';

SELECT * FROM sys_user u WHERE u.outer_user_id in(28457,28456);

-- UT432582138907328512
-- UT432582344977678336
-- UT432582138907328512

