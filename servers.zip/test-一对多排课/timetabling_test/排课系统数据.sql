SELECT * FROM `ct_classroom` c where c.id = '1806';

SELECT * FROM ct_course c where c.id = '314';
-- timetabling_test库
# 订单表
SELECT * FROM ct_order WHERE id = '69564';
#用户表
SELECT * FROM ct_user u where u.id = '8031';