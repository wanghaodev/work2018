SELECT * FROM t_sharks_product p ORDER BY p.id DESC;

SELECT * FROM t_kooup_product_info pf WHERE pf.product_code = 'P428212854429057024';

SELECT  * FROM t_kooup_course_info;

SELECT * FROM t_kooup_classroom_lecturer c WHERE c.teacher_name = 'zhibo031602';

SELECT * FROM t_sharks_exam_season s WHERE  s.`name` like '%2018%';


SELECT * FROM t_kooup_live l WHERE l.live_name = '20180324直播课';

SELECT * FROM t_kooup_course_info  c where c.outer_course_id =4864 ;

SELECT * FROM t_kooup_lesson_info;

SELECT * FROM t_kooup_classroom_teacher ORDER BY create_time DESC;

SELECT * FROM t_kooup_classroom_lecturer t WHERE t.teacher_code = 'UT430318995481034752' ORDER BY create_time DESC;
-- teacher_code:UT430318995481034752

SELECT * FROM t_teacher_base ;

SELECT * FROM t_account_validity ORDER BY create_time DESC;

SELECT * FROM t_kooup_student t WHERE t.student_name like '%0316%' ORDER BY create_time DESC;

SELECT * FROM sys_user u where u.user_code = 'U425225611179458560' ORDER BY create_time DESC;

SELECT * FROM t_kooup_class_info c WHERE c.outer_class_id = '1951';
-- 1951 ---服务没有关联直播课程的班级测试

SELECT * FROM t_kooup_class_student ct WHERE ct.class_code ='CLS426123378567413760' ORDER BY create_time DESC;

SELECT * FROM t_kooup_lesson_info lf WHERE lf.class_code = 'CLS428256123934474240';

SELECT * FROM t_kooup_course_info f WHERE f.course_code ='PC428212854630383616' ;

SELECT * FROM t_kooup_lesson_student lt WHERE lt.student_code = 'STU426116019266781184' ORDER BY lt.create_time DESC;
-- MQ
SELECT * FROM t_kooup_mq_chanage_notify mq WHERE mq.is_new_flag = 1 ORDER BY create_time;