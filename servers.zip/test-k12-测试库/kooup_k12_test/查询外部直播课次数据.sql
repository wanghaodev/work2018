SELECT
        ScheduleLesson.id,
        ScheduleLesson.`subject`,
        ScheduleLesson.start_time,
        ScheduleLesson.end_time,
        live.live_status as state,
        classInfo.class_code,
        classroomteacher.teacher_code AS classroom_teacher_code,
        live.teacher_code AS  live_teacher_code,
        courseInfo.course_code,
        lessonLiveRel.live_id,
        lessonLiveRel.group_id,
        live.live_code,
        live.live_num
    FROM
        t_schedule_lesson ScheduleLesson
    LEFT JOIN t_schedule_lesson_live_rel lessonLiveRel ON ScheduleLesson.id = lessonLiveRel.lesson_id
    LEFT JOIN t_kooup_live live ON live.id = lessonLiveRel.live_id
    LEFT JOIN t_kooup_class_info classInfo ON classInfo.outer_class_id = ScheduleLesson.classroom_id
    LEFT JOIN t_kooup_course_info courseInfo ON courseInfo.outer_course_id = lessonLiveRel.group_id
    LEFT JOIN t_schedule_user scheduleUser ON scheduleUser.id = ScheduleLesson.teacher_id
    LEFT JOIN sys_user kooupUser ON kooupUser.outer_user_id = scheduleUser.sso_id
    LEFT JOIN t_kooup_classroom_teacher classroomteacher ON classroomteacher.user_code = kooupUser.user_code
      WHERE 1=1