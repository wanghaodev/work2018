SELECT
	count(1)
FROM
	t_kooup_class_student cstu
WHERE cstu.join_status in(0,1,2)
AND cstu.history = 0
AND cstu.validation = 1
AND cstu.class_code = 'CLS428651751424393216'
 GROUP BY cstu.class_code;

SELECT
	count(1)
FROM
	t_kooup_class_student cstu
WHERE cstu.join_status in(0)
AND cstu.history = 0
AND cstu.validation = 1
AND cstu.class_code = 'CLS428651751424393216'
 GROUP BY cstu.class_code;


UPDATE t_kooup_class_info cinfo
          SET cinfo.student_number = IF NULL(
                  (
                      SELECT
                          count(stu.id) AS num
                      FROM
                          t_kooup_class_student stu
                      WHERE
                          stu. STATUS IN (0, 1, 2)
                      AND stu.class_code = cinfo.class_code
                      AND stu.validation = 1
                      AND stu.history = 0
                      GROUP BY
                          stu.class_code
                    ),
                    0
                )
          ,cinfo.effective_student_number =IFNULL(
                (
                    SELECT
                        count(stu.id) AS num
                    FROM
                        t_kooup_class_student stu
                    WHERE
                        stu.class_code = cinfo.class_code
                    AND stu. STATUS IN (0)
                    AND stu.validation = 1
                    AND stu.history = 0
                    GROUP BY
                        class_code
                ),
                0
            )
        where  cinfo.outer_class_id = 1911