SELECT
          @order_number := @order_number + 1 AS order_number,
          lives.*
      FROM
          (
              SELECT DISTINCT
                  live.id live_id,
                  live.`name` AS live_name,
                  live.start_time,
                  live.end_time,
                  live.push_flow_type
              FROM
                  t_sharks_live live
              LEFT JOIN t_sharks_live_group_relationship rel ON rel.live_id = live.id
              WHERE
                  1 = 1
              AND rel.live_group_id = 4865
              AND live.`status` =3
							AND live.product_line in(3,24,25)
              ORDER BY
                  start_time ASC
          ) AS lives,
          (SELECT @order_number := 0) T3
      ORDER BY
          order_number