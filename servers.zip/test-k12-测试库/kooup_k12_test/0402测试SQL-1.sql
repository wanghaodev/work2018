SELECT DISTINCT
	CourseTeacherRel.course_id AS service_id,
	KooupClassTeacher.teacher_code
FROM
	t_kooup_classroom_teacher KooupClassTeacher
LEFT JOIN t_teacher_base TeacherBase ON TeacherBase.id = KooupClassTeacher.id
LEFT JOIN t_schedule_user ScheduleUser ON ScheduleUser.sso_id = TeacherBase.user_id
LEFT JOIN t_schedule_course_teacher_rel CourseTeacherRel ON CourseTeacherRel.teacher_id = ScheduleUser.id
WHERE
	CourseTeacherRel.course_id = 400;
-- 7866
SELECT * FROM t_schedule_user  u  WHERE u.sso_username ='xueguan031602';

SELECT * FROM sys_user u where u.show_name = 'xueguan032601';

SELECT * FROM t_schedule_teacher  t WHERE t.id = '7976';

SELECT * FROM t_kooup_wait_assign_teacher wat where wat.service_id = 400;

SELECT * FROM t_schedule_course_teacher_rel t WHERE t.course_id = '400';

SELECT * FROM t_kooup_classroom_lecturer  r WHERE   r.teacher_name = 'zhibo031602';

SELECT * FROM t_kooup_classroom_teacher ct WHERE ct.work_account = 'xueguan032601';

SELECT * FROM t_kooup_file f WHERE f.file_code  = 'F430451445934850048';
