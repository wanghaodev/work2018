SELECT
          DISTINCT
          cf.product_code,
					start_time,
          (CASE WHEN scheduleK12Ext.start_time>NOW() THEN 0 ELSE 1 END) AS product_assign_status
       FROM
          t_kooup_course_info cf
      LEFT JOIN t_schedule_k12_course_extendinfo scheduleK12Ext ON cf.service_id = scheduleK12Ext.course_id
      WHERE
          1 = 1
       AND scheduleK12Ext.start_time IS NOT NULL
