SELECT * FROM `t_schedule_course`;

SELECT * FROM t_sharks_live_group lg WHERE lg.`name` like '%0319%'

SELECT * FROM t_sharks_live l where l.`name` like '%0319小学语文%';

SELECT * FROM t_sharks_product p where p.`name`  like '%0319%';

SELECT * FROM t_teacher_base t where t.`name`  like '%xueguan031603%';