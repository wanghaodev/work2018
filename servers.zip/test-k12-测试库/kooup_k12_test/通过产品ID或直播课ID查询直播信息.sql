SELECT
        DISTINCT
        sharksLive.id,
        sharksLive.product_line,
        sharksLive.exam_season_id,
        sharksLive.subject_id,
        sharksLive. NAME,
        sharksLive.start_time,
        sharksLive.end_time,
        sharksLive.live_type,
        sharksLive.push_flow_type,
        sharksLive.create_time,
        sharksLive.create_uid,
        sharksLive.create_username,
        sharksLive.update_time,
        sharksLive.update_uid,
        sharksLive.update_username,
        sharksLive.is_deleted,
        sharksLive.push_flow_type AS push_flow_type,
        sharksLive.subject_id,
        sharksExamSeason.id AS exam_season_id,
        sharksExamSeason.`code` AS examSeasonCode,
        sharksExamSeason.`name` AS examSeasonName,
        liveGroup.service_id AS service_id,
        liveGroup.id AS live_group_id,
        liveTeacher.teacher_id AS live_teacher_id
        FROM
        t_sharks_live sharksLive
        LEFT JOIN t_sharks_live_group_relationship liveGroupRelationship ON liveGroupRelationship.live_id =
        sharksLive.id
        LEFT JOIN t_sharks_live_group liveGroup ON liveGroup.id = liveGroupRelationship.live_group_id
        LEFT JOIN t_sharks_product_item productItem ON productItem.item_id = liveGroup.id
        LEFT JOIN t_sharks_live_teacher liveTeacher ON liveTeacher.live_id = sharksLive.id
        LEFT JOIN t_sharks_exam_season sharksExamSeason ON sharksExamSeason.id = sharksLive.exam_season_id
WHERE sharksLive.`name` = '0325-初中语文第五讲'