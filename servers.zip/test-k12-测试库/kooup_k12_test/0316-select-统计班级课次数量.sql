SELECT * FROM t_kooup_class_info  classInfo LEFT JOIN t_kooup_course_info corseInfo
ON classInfo.course_code = corseInfo.course_code
LEFT JOIN t_kooup_live  live ON live.outer_course_id  = corseInfo.outer_course_id
WHERE classInfo.class_code = 'CLS423934188421382144';

-- PC423845320498085888
-- 统计班级课次数量
SELECT * FROM t_kooup_live  live LEFT JOIN t_kooup_course_info corseInfo
ON live.outer_course_id  = corseInfo.outer_course_id
LEFT JOIN t_kooup_class_info  classInfo ON classInfo.course_code = corseInfo.course_code
WHERE classInfo.class_code='CLS423948154480623616'