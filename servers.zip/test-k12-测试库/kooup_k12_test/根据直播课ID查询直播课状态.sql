SELECT
	l.`status`,
	l.disuse_reason
FROM
	t_sharks_live l
WHERE
	l.id = '6919'