SELECT
	cf.class_code,
	cf.outer_class_id,
	cf.class_name,
	(CASE  WHEN cstu.`status` in(0)  then  COUNT(1) ELSE 0 END)as student_number,
	(CASE  WHEN cstu.`status` in(0,1,2)  then  COUNT(1) ELSE 0 END)as effective_student_number
FROM
	t_kooup_class_student cstu
LEFT JOIN t_kooup_class_info cf ON cstu.class_code = cf.class_code
WHERE
	cstu.`status` IN (0)
AND cf.outer_class_id = '1866';