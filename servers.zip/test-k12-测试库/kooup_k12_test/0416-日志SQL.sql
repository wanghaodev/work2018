SELECT * from t_schedule_classroom where id = 1668;
SELECT * from t_sharks_live_group where service_id = 57;

SELECT * FROM t_sharks_exam_season s where s.id = '3';

SELECT * FROM t_sharks_product_line_def d where d.id = 2;

SELECT p.`name`,p.item_id,p.item_type,COUNT(*)as count  FROM t_sharks_product_item p WHERE p.item_type =18 GROUP BY p.item_id having count>1;

SELECT * FROM t_sharks_product p where p.id in(4333,4334,4337,4339,4341,4350)