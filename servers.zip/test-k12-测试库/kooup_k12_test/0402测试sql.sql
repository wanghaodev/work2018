SELECT * FROM t_kooup_classroom_teacher t WHERE t.teacher_name like '%达摩%';

SELECT * FROM sys_user u where u.user_code = 'U430403620819697664';

SELECT * FROM t_kooup_file f WHERE f.file_code  = 'F430403908527980544';

SELECT * FROM t_kooup_product_info WHERE product_name = '初中2018暑季k12双师直播测试1';


SELECT * FROM t_kooup_live l where l.id in(7075,7076);

SELECT * FROM t_kooup_live l where l.validation  = 0;

SELECT * FROM t_sharks_product p WHERE p.id in(
SELECT product_id FROM t_sharks_product_item t where t.item_id = '4871' AND  t.item_type =18
)

-- 初中2018暑季k12双师直播测试1