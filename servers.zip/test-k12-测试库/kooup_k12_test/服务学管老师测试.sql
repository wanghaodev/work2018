SELECT * FROM t_schedule_course_teacher_rel ctr WHERE ctr.course_id ='395';

SELECT * FROM t_kooup_wait_assign_teacher wat WHERE wat.service_id = '400';

SELECT * FROM t_kooup_mq_chanage_notify mq where   mq.is_new_flag = 1;

SELECT * FROM t_teacher_base tb where  tb.id = '7866';

SELECT * FROM t_teacher_base t WHERE t.`name` = 'xueguan032601'; 

SELECT * FROM sys_user u WHERE u.show_name = 'xueguan032601';
-- 老师
SELECT * FROM t_kooup_classroom_lecturer l WHERE l.user_code = 'U430421789789650944';
-- 直播老师
SELECT * FROM t_kooup_classroom_teacher t WHERE t.user_code = 'U430421789789650944';
-- 学生
SELECT * FROM t_kooup_student t WHERE  t.user_code = 'U430421789789650944';

select id, name, capacity, reverse_num, lesson_duration, remedy_num, reverse_type, remark, status, type, course_content_id, support_reserve, state, create_time, update_time, creator, new_flag from t_schedule_course where id = 395 

select id, course_id, consultant_id, is_deafult, state, create_time, new_flag, update_time from t_schedule_course_consultant_rel where id = '2917' ;

select id, course_id, teacher_id, state, create_time, new_flag, update_time from t_schedule_course_teacher_rel where id = '2766';

SELECT * FROM t_kooup_class_info c where c.outer_class_id = '1911';

SELECT * FROM sys_user u where u.outer_user_id = '69377';
-- '69377';

SELECT * FROM t_kooup_class_student  cs where cs.class_code = 'CLS428651751424393216';

