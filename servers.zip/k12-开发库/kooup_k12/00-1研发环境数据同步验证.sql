#1、创建服务

SELECT * FROM t_sharks_product p ORDER BY p.id DESC;

SELECT * FROM t_kooup_product_info pf WHERE pf.product_code = 'P426110242741288960';

SELECT  * FROM t_kooup_course_info;

SELECT * FROM t_kooup_live l where l.product_code = 'P426692852379025408';

SELECT * FROM t_kooup_lesson_info;

SELECT * FROM t_kooup_classroom_teacher  ORDER BY create_time DESC;

SELECT * FROM t_kooup_classroom_lecturer ORDER BY create_time DESC;

SELECT * FROM t_teacher_base ;

SELECT * FROM t_account_validity a where a.order_no = '5219324286' ORDER BY create_time DESC;

SELECT * FROM t_kooup_student t WHERE t.student_name like '%0316%' ORDER BY create_time DESC;

SELECT * FROM sys_user u where u.user_code = 'U425225611179458560' ORDER BY create_time DESC;

-- 259
SELECT * FROM t_schedule_classroom c where c.id='259';

SELECT * FROM t_kooup_class_info c WHERE c.class_code = 'CLS436221168513449984';

SELECT * FROM t_kooup_class_student ct WHERE ct.class_code ='CLS426123378567413760' ORDER BY create_time DESC;

SELECT * FROM t_kooup_lesson_info lf WHERE lf.class_code = 'CLS426123378567413760';

SELECT * FROM t_kooup_lesson_student lt WHERE lt.student_code = 'STU426116019266781184' ORDER BY lt.create_time DESC;
