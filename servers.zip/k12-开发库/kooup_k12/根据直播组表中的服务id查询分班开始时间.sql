SELECT 
course.id,
course.name,
k12CourseExtendinfo.*
FROM 
t_schedule_course  course LEFT JOIN 
t_schedule_k12_course_extendinfo  k12CourseExtendinfo  ON course.id = k12CourseExtendinfo.course_id
WHERE course.type=2
AND course.id='324'