UPDATE t_kooup_product_info pf
SET pf.product_assign_status = 1
WHERE 1=1
AND pf.product_code IN 
(
SELECT
	cf.product_code
FROM
	t_kooup_course_info cf
LEFT JOIN t_schedule_k12_course_extendinfo scheduleK12Ext ON cf.service_id = scheduleK12Ext.course_id
WHERE
	1 = 1
AND scheduleK12Ext.start_time IS NOT NULL 
AND DATE_FORMAT(scheduleK12Ext.start_time,'%Y-%m-%d') <= '2018-03-12'
)