SELECT * FROM t_sharks_live ORDER BY create_time DESC;

SELECT * FROM t_sharks_live_group  ORDER BY create_time DESC;

SELECT * FROM t_sharks_live_teacher  ORDER BY create_time DESC;

SELECT * FROM t_kooup_live;

SELECT * FROM t_kooup_course_info;

