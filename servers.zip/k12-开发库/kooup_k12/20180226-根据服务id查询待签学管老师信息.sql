SELECT
	CourseTeacherRel.course_id AS service_id,
	KooupClassTeacher.teacher_code,
	KooupClassTeacher.teacher_name,
	KooupCourseInfo.course_code,
	KooupCourseInfo.course_name
FROM
	t_kooup_classroom_teacher KooupClassTeacher
LEFT JOIN t_teacher_base TeacherBase ON TeacherBase.id = KooupClassTeacher.id
LEFT JOIN t_schedule_user ScheduleUser ON ScheduleUser.sso_id = TeacherBase.user_id
LEFT JOIN t_schedule_course_teacher_rel CourseTeacherRel ON CourseTeacherRel.teacher_id = ScheduleUser.id
LEFT JOIN t_kooup_course_info KooupCourseInfo ON KooupCourseInfo.service_id = CourseTeacherRel.course_id
WHERE
	KooupCourseInfo.service_id = 54