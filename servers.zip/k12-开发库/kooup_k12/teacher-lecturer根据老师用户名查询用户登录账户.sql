SELECT
	user.photo AS userphoto,
	teacher.mobile,
	teacher.mail,
	teacher.work_account
FROM
	`sys_user` USER
LEFT JOIN t_kooup_classroom_lecturer teacher ON teacher.teacher_name = USER .show_name
WHERE
	teacher.teacher_name LIKE '%wh2018020601%'