UPDATE t_kooup_lesson_info linfo
SET linfo.student_number = (
	SELECT
		sum(1)
	FROM
		t_kooup_lesson_student stu
	WHERE
		stu.lesson_code = linfo.lesson_code
)
WHERE
	EXISTS (
		SELECT
			1
		FROM
			t_kooup_class_info cinfo
		WHERE
			cinfo.class_code = linfo.class_code
		AND cinfo.outer_class_id = 207
	)