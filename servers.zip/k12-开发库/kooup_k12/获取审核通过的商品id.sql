SELECT DISTINCT
	sharksProduct.id
FROM
	t_sharks_product sharksProduct
RIGHT JOIN t_sharks_product_item sharksProductItem ON sharksProduct.id = sharksProductItem.product_id
LEFT JOIN t_sharks_live_group_relationship liveGroupRelationship ON sharksProductItem.item_id = liveGroupRelationship.live_group_id
LEFT JOIN t_sharks_live_group sharksLiveGroup ON sharksLiveGroup.id = liveGroupRelationship.live_group_id
LEFT JOIN t_sharks_live sharksLive ON sharksLive.id = liveGroupRelationship.live_id
LEFT JOIN t_sharks_exam_season sharksExamSeason ON sharksExamSeason.id = sharksLiveGroup.exam_season_id
WHERE
sharksProduct.`status` = 3
AND sharksLiveGroup.live_type = 2
