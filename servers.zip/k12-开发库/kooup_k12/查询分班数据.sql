-- 班级
SELECT * FROM t_kooup_class_info ci WHERE ci.class_name like '%榴莲%'
-- 用户信息(插入学员时必须保持t_schedule_user表有用户信息)
select id, sso_id, sso_username, type, new_flag from t_schedule_user  WHERE sso_username like '%hannuoyi%';

-- 班级信息
-- CLS421099418318536704  榴莲忘返#2班
-- CLS421048877072777216 榴莲忘返#1班
SELECT * FROM t_kooup_lesson_info l WHERE  l.class_code ='CLS421099418318536704' 
-- CLS421099418318536704 -- L421099494193496064，L421099498555572224
-- CLS421048877072777216 -- 421048949026062336，L421048945964220416
 -- 查询分班后的数据
select * FROM t_kooup_lesson_student  ls where ls.class_code = 'CLS421099418318536704';
