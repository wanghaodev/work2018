select 
 KooupCourseInfo.id
,KooupCourseInfo.course_code
,KooupCourseInfo.course_name
,KooupCourseInfo.course_status
,KooupCourseInfo.product_code
,KooupCourseInfo.subject_id
,KooupCourseInfo.create_time
,KooupCourseInfo.update_time
,KooupCourseInfo.validation
,KooupCourseInfo.carete_user_code
,KooupCourseInfo.update_user_code
,KooupCourseInfo.outer_course_id
,KooupCourseInfo.service_id
from 
t_kooup_course_info KooupCourseInfo
WHERE 1=1
AND KooupCourseInfo.outer_course_id='4752'
