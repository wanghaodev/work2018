
SELECT COUNT(1) FROM t_kooup_lesson_student ls WHERE ls.lesson_code = 'L05CLASSDYC00000002';