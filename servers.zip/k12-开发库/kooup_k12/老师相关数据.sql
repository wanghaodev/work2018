SELECT * FROM sys_user u where u.show_name ='zhibo0412';

SELECT * FROM t_kooup_classroom_lecturer ct where ct.work_account = 'zhibo0412';
-- 老师数据同步SQL
SELECT DISTINCT t.* FROM t_teacher_base t LEFT JOIN t_teacher_catagory_associate tca ON t.id = tca.teacher_id WHERE tca.second_catagory IN (208, 209, 210) AND t.id = 10072 