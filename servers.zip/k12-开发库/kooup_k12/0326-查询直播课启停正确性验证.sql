SELECT * FROM t_kooup_lesson_info l WHERE l.course_code = 'PC427616440414109696' AND l.disuse = 1;

SELECT * FROM t_kooup_live l where l.product_code = 'P427616439352950784' AND l.validation = 1;

-- liveid:10236