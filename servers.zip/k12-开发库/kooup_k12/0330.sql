SELECT * FROM DISTINCT t_kooup_live;
UPDATE t_kooup_wait_assign_teacher w
SET w.validation = 1
WHERE
	w.course_code = 'PC419090116787568640'
AND w.teacher_code = 'U419078931291832320';


SELECT * FROM t_kooup_wait_assign_teacher w WHERE w.course_code='PC419090116787568640' AND w.teacher_code = 'U419078931291832320';


-- ###################################################################
SELECT * FROM t_schedule_course c WHERE c.`name` = '032601服务11';
SELECT * FROM t_schedule_course_teacher_rel tr where  tr.course_id = '90';
SELECT * FROM t_kooup_wait_assign_teacher wt where  wt.service_id =90;
SELECT * FROM sys_user u where u.user_code in ('U421249241248169984','U426763030617915392');

SELECT * FROM t_kooup_classroom_teacher t WHERE t.teacher_code in('U421249241789235200','U426764087972593664');

SELECT DISTINCT ct.course_id,ct.teacher_id FROM t_schedule_course_teacher_rel ct WHERE ct.course_id = '50' AND ct.teacher_id ='59'
