SELECT
        DISTINCT
            productItem.product_id,
            liveGroup.service_id,
            liveGroupRelationship.live_group_id
        FROM
            t_sharks_live sharksLive
        LEFT JOIN t_sharks_live_group_relationship liveGroupRelationship ON liveGroupRelationship.live_id = sharksLive.id
        LEFT JOIN t_sharks_live_group liveGroup ON liveGroup.id = liveGroupRelationship.live_group_id
        LEFT JOIN t_sharks_product_item productItem ON productItem.item_id = liveGroup.id
        WHERE
            sharksLive.id = 10235