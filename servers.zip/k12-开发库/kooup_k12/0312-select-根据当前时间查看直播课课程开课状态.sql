-- 直播课课程开课状态(0：未开始)小于开始时间
SELECT * FROM t_kooup_live live WHERE DATE_FORMAT('2018-03-12','%Y%m%d')< live.start_time;
-- 直播课课程开课状态(1：进行中)
SELECT * FROM t_kooup_live live WHERE live.start_time <=DATE_FORMAT('2018-03-12 00:00:00','%Y%m%d');
-- 直播课课程开课状态(2：已结束)大于结束时间
SELECT * FROM t_kooup_live live WHERE live.end_time < DATE_FORMAT('2018-03-12','%Y%m%d');

