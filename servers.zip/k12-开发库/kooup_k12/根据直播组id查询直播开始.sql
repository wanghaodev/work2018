SELECT
	MIN(SharksLive.start_time) start_time,
	MAX(SharksLive.end_time) end_time
FROM
	t_sharks_live SharksLive
LEFT JOIN t_sharks_live_group_relationship liveGroupRelationship ON SharksLive.id = liveGroupRelationship.live_id
WHERE
	liveGroupRelationship.live_group_id = '140'