SELECT DISTINCT
	sharksProduct.id,
	sharksProduct.product_line,
	sharksProduct. NAME,
	sharksProduct.display_name,
	sharksProduct. CODE,
	sharksProduct.launch_date,
	sharksProduct.bill_type,
	sharksProduct.expiration_date,
	sharksProduct.activity_days,
	sharksProduct.picture_url,
	sharksProduct.description,
	sharksProduct.original_price,
	sharksProduct.current_price,
	sharksProduct. STATUS,
	sharksProduct.extension_type,
	sharksProduct.protocol_id,
	sharksProduct.display_product_info,
	sharksProduct.create_time,
	sharksProduct.create_uid,
	sharksProduct.create_username,
	sharksProduct.update_time,
	sharksProduct.update_uid,
	sharksProduct.update_username,
	sharksProduct.is_deleted,
	sharksProduct.first_online_time,
	sharksProduct.sales_count,
	sharksProduct.initial_sales_count,
	sharksProduct.last_offline_time,
	sharksProduct.pre_sales_name,
	sharksProductItem.product_id,
	sharksExamSeason.id AS exam_season_id,
	sharksExamSeason.`code` AS examSeasonCode,
	sharksExamSeason.`name` AS examSeasonName,
	sharksLiveGroup.subject_id AS subject_id,
	sharksLiveGroup.service_id AS service_id,
	sharksLiveGroup.id AS live_group_id
FROM
	t_sharks_product sharksProduct
LEFT JOIN t_sharks_product_line_def productLine ON sharksProduct.product_line = productLine.id
LEFT JOIN t_sharks_product_item sharksProductItem ON sharksProduct.id = sharksProductItem.product_id
LEFT JOIN t_sharks_live_group_relationship liveGroupRelationship ON sharksProductItem.item_id = liveGroupRelationship.live_group_id
LEFT JOIN t_sharks_live_group sharksLiveGroup ON sharksLiveGroup.id = liveGroupRelationship.live_group_id
LEFT JOIN t_sharks_live sharksLive ON sharksLive.id = liveGroupRelationship.live_id
LEFT JOIN t_sharks_exam_season sharksExamSeason ON sharksExamSeason.id = sharksLiveGroup.exam_season_id
WHERE
	1 = 1
AND sharksProduct.`status` IN (3,5,6)
AND sharksLiveGroup.live_type = 2
AND productLine.enum_code IN (
	'ChuZhong',
	'GaoZhong',
	'XiaoXue'
)
AND sharksProduct.id = '5945'