SELECT
	ScheduleClassroom.id,
	ScheduleClassroom.`name`,
	ScheduleClassroom.course_id AS service_id,
	ScheduleClassroom.create_time,
	ScheduleClassroom.update_time,
	ScheduleClassroom.`status` AS validation,
	ScheduleClassroom.state AS is_delete,
	SharksLiveGroup.id AS course_id
FROM
	t_schedule_classroom ScheduleClassroom
LEFT JOIN t_sharks_live_group SharksLiveGroup ON SharksLiveGroup.service_id = ScheduleClassroom.course_id
WHERE ScheduleClassroom.id='194'
