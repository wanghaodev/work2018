-- 用户数据

-- 查询产品
SELECT * FROM `t_sharks_product` product WHERE  product.`name` like '%032601产品%';
-- 待签老师
SELECT * FROM `t_kooup_wait_assign_teacher` t WHERE  t.teacher_code ='U420612384818724864';
-- 业务产品数据
SELECT * FROM t_kooup_product_info pf WHERE pf.outer_product_id = '5994';

-- 课程
SELECT * FROM t_kooup_course_info cf WHERE  cf.outer_course_id = 187;
-- 直播课 
SELECT * FROM t_kooup_live  l WHERE l.outer_course_id = 187;

SELECT * FROM t_schedule_course c WHERE c.`name` like '%0307服务%' ORDER BY id DESC;

SELECT * FROM `t_sharks_product_extended_attribute` WHERE product_id = '5966';



--  下单数据查询
SELECT * from t_kooup_student s  WHERE s.student_code = 'STU421681533607215104';

SELECT * FROM sys_user u WHERE u.outer_user_id = '67340979';
-- user_Id 67340937
SELECT * FROM t_account_validity cv  WHERE cv.order_no = '0410615123';

SELECT * FROM t_account_validity cv  WHERE cv.user_id ='67340979';

-- 分班
SELECT * FROM t_kooup_class_info clf  WHERE clf.class_name  like '%初一#3班%';

SELECT * FROM t_kooup_class_info clf  WHERE clf.outer_class_id = '251';


--  课次
SELECT * FROM t_kooup_lesson_info lf WHERE lf.class_code = 'CLS427618767967617024';
-- 班级学生
SELECT * FROM t_kooup_class_student   cs WHERE cs.class_code = 'CLS421324947709755392';

-- 课次学生表
SELECT * FROM t_kooup_lesson_student  cs WHERE cs.lesson_code in('L421690926470004736','L421690927401140224');




