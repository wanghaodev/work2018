SELECT
	COUNT(LessonStudent.student_code) AS studnet_number
FROM
	t_kooup_class_info ClassInfo
LEFT JOIN t_kooup_lesson_student  LessonStudent ON LessonStudent.class_code = ClassInfo.class_code
WHERE
	ClassInfo.outer_class_id = '198'