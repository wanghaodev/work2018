UPDATE t_kooup_class_info cf
SET cf.class_status = 1
WHERE
	cf.class_status = 0
AND cf.course_code IN (
	SELECT
		cf.course_code
	FROM
		t_kooup_course_info cf
	LEFT JOIN t_schedule_k12_course_extendinfo scheduleK12Ext ON cf.service_id = scheduleK12Ext.course_id
	WHERE
		scheduleK12Ext.start_time IS NOT NULL
	AND DATE_FORMAT(
		scheduleK12Ext.start_time,
		'%Y-%m-%d'
	) <= '2018-03-12'
)