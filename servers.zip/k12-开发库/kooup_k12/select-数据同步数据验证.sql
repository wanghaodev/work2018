SELECT * FROM  t_schedule_course c WHERE c.`name` like  '%0316%';

SELECT * FROM t_sharks_live live where live.`name` like '%0316%';

SELECT * FROM t_sharks_course c WHERE c.`name` like '%0316%';

SELECT * FROM t_sharks_product p WHERE p.`name` like '%031601产品%';

SELECT * from sys_user u where u.show_name = 'liveTeacher0316';

SELECT * FROM t_teacher_base t WHERE t.`name`= 'liveTeacher0316';


SELECT * FROM t_teacher_catagory_associate  tc WHERE tc.teacher_id = '10056';

 select  * from t_teacher_base t WHERE t.id = '10056'

