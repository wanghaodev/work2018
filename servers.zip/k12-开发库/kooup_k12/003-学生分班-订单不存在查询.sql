#排课订单
SELECT * FROM t_schedule_order o where o.course_id ='98';
#排课用户
SELECT * from t_schedule_user where id = '8031';

-- [150],"oriClassroomId":null,"targetClassroomId":261}

-- 153	191	98	1	1	2018-04-21 16:41:24	1	2018-04-21 16:41:24

SELECT * FROM t_kooup_class_info c WHERE c.class_code in('CLS437273165639450624','CLS437286310248448000');

-- 0420#测试2班
SELECT * FROM t_kooup_class_student s where s.class_code ='CLS437286310248448000';