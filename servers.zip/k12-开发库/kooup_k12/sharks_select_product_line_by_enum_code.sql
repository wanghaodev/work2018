SELECT
	id
FROM
	t_sharks_product_line_def productLine
WHERE
	productLine.enum_code IN (
		'ChuZhong',
		'GaoZhong',
		'XiaoXue'
	) ；