-- 通过排课系统用户id查询业务系统老师编码
SELECT
	classroomTeacher.teacher_code
FROM
	t_schedule_teacher scheduleTeacher
LEFT JOIN t_schedule_user scheduleUser ON scheduleTeacher.id = scheduleUser.id
LEFT JOIN t_teacher_base teacherBase ON teacherBase.user_id = scheduleUser.sso_id
LEFT JOIN t_kooup_classroom_teacher classroomTeacher  ON classroomTeacher.id = teacherBase.id
WHERE scheduleUser.id = 88