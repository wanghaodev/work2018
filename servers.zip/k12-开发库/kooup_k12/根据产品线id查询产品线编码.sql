SELECT
	productLineDef.enum_code
FROM
	t_sharks_product_line_def productLineDef
LEFT JOIN t_sharks_product_line_category productLineCategory ON productLineDef.product_line_category_id = productLineCategory.id
WHERE
	productLineCategory.enum_code = 'K12'
AND productLineDef.id = 24