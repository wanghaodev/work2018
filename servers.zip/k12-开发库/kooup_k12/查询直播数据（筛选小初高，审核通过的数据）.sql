SELECT
	sharksLive.id,
	sharksLive.product_line,
	sharksLive.exam_season_id,
	sharksLive.subject_id,
	sharksLive. NAME AS live_name,
	sharksLive.start_time,
	sharksLive.end_time,
	sharksLive.live_type,
	sharksLive.push_flow_type,
	sharksLive.create_time,
	sharksLive.create_uid,
	sharksLive.create_username,
	sharksLive.update_time,
	sharksLive.update_uid,
	sharksLive.update_username,
	sharksLive.is_deleted,
	sharksLive.push_flow_type AS push_flow_type,
	sharksLive.subject_id AS subject_id,
	sharksExamSeason.`code` AS exam_season_code,
	sharksExamSeason.`name` AS exam_season_name,
	liveGroupRelationship.live_group_id live_group_id,
	sharksProduct.id AS sharks_product_id,
	shrksLiveTeacher.teacher_id AS live_teacher_id
FROM
	t_sharks_product sharksProduct
LEFT JOIN t_sharks_product_line_def productLine ON productLine.id = sharksProduct.product_line
LEFT JOIN t_sharks_product_item sharksProductItem ON sharksProduct.id = sharksProductItem.product_id
LEFT JOIN t_sharks_live_group_relationship liveGroupRelationship ON sharksProductItem.item_id = liveGroupRelationship.live_group_id
LEFT JOIN t_sharks_live_group sharksLiveGroup ON sharksLiveGroup.id = liveGroupRelationship.live_group_id
LEFT JOIN t_sharks_live sharksLive ON sharksLive.id = liveGroupRelationship.live_id
LEFT JOIN t_sharks_exam_season sharksExamSeason ON sharksExamSeason.id = sharksLive.exam_season_id
LEFT JOIN t_sharks_live_teacher shrksLiveTeacher ON shrksLiveTeacher.live_id = sharksLive.id
WHERE
	sharksProduct.`status` = 3
AND sharksLiveGroup.live_type = 2
AND sharksLive.new_flag=0
AND productLine.enum_code IN('XiaoXue', 'ChuZhong', 'GaoZhong')