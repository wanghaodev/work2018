-- 根据产品查询到直播组，在根据直播组id查询对应的服务id和服务老师id
SELECT
	ScheduleCourseTeacherRel.teacher_id,
	ScheduleCourseTeacherRel.course_id,
	ScheduleCourseTeacherRel.create_time,
	ScheduleCourseTeacherRel.update_time,
	liveGroup.id AS live_group_Id
FROM
	t_schedule_course_teacher_rel ScheduleCourseTeacherRel
LEFT JOIN t_sharks_live_group liveGroup ON ScheduleCourseTeacherRel.course_id = liveGroup.service_id
WHERE
	liveGroup.id = '317';