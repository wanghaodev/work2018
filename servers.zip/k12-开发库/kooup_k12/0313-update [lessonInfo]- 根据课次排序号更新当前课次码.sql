UPDATE t_kooup_lesson_info lesson
SET lesson.current = 1
WHERE
	lesson.lesson_status = 0
AND lesson.lesson_order = ''
AND lesson.course_code = ''