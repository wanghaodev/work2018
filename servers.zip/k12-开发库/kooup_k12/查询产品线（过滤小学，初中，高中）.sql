SELECT
	productLine.id,
	productLine.enum_code,
	productLine.`name`,
	productLine.shorter
FROM
	t_sharks_product_line_def productLine
WHERE productLine.enum_code IN ('ChuZhong','GaoZhong','XiaoXue')