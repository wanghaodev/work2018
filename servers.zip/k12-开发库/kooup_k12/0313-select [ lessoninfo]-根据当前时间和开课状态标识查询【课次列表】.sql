SELECT
	lesson.lesson_code,
	lesson.live_code,
	lesson.lesson_order,
	lesson.lesson_status,
	lesson.current
FROM
	t_kooup_lesson_info lesson
WHERE
	lesson.validation = 1
AND DATE_FORMAT('2018-03-12 07:00','%Y-%m-%d %H:%i') 
BETWEEN DATE_FORMAT(lesson.start_time, '%Y-%m-%d %H:%i')
AND DATE_FORMAT(lesson.end_time, '%Y-%m-%d %H:%i')