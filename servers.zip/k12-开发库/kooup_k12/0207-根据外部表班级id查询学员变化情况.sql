SELECT
	COUNT(ClassStudent.student_code) AS studnet_number
FROM
	t_kooup_class_info ClassInfo
LEFT JOIN t_kooup_class_student ClassStudent ON ClassInfo.class_code = ClassStudent.class_code
WHERE
	ClassInfo.outer_class_id = '198'