select id,
 NAME,
 STATUS,
 state,
 create_time,
 update_time,
 creator,
 new_flag
FROM
	t_schedule_assistant
WHERE
	id = '81'