-- 1、创建基本数据（老师，学管，学生，顾问，用户）
-- 用户信息
select * FROM sys_user u WHERE u.show_name LIKE '%zhibo0308%';
-- 学管信息
select * FROM t_kooup_classroom_teacher ct where ct.teacher_name like '%xueguan0308%';

-- 直播老师
select * FROM t_kooup_classroom_lecturer cl WHERE cl.teacher_name like '%zhibo0308%';

-- 顾问
SELECT * FROM t_schedule_consultant cn WHERE cn.`name` like '%guwen0308%';

-- 2、#############################服务数据查询,建服务，建课，建产品

-- 直播课 Id(10200,10201)
SELECT * FROM t_sharks_live l WHERE l.`name` like '%0308%';
-- 产品
SELECT * FROM t_sharks_product p WHERE p.`name` like '%0308%';

SELECT * FROM t_kooup_product_info kp WHERE kp.product_name like '%0308%';

SELECT * FROM t_sharks_product_extended_attribute patt WHERE patt.product_id = '5968';
-- 业务直播课
SELECT * FROM t_kooup_live live WHERE live.live_name like '%0308%';

-- 课程查询
SELECT * FROM t_kooup_course_info cf WHERE cf.course_name  like '%0308%';

-- 3、下单（同步学生，账户有效性，订单数据）

SELECT * FROM t_account_validity cv WHERE  cv.order_no = '0814661672';

SELECT * FROM t_kooup_student ks ORDER BY ks.id DESC;

-- 排课系统学生用户表
SELECT * FROM t_schedule_user u WHERE u.sso_username = 'stu030804';

-- 4、 分班
SELECT * FROM t_kooup_wait_assign_teacher;

-- CLS421279249924620288
SELECT * FROM t_kooup_class_info WHERE outer_class_id = '230';

SELECT * FROM t_kooup_lesson_info WHERE class_code = 'CLS421322675999211520';

SELECT * FROM t_kooup_lesson_student ls WHERE ls.lesson_code in ('L421279453000237056','L421279453511942144')  ORDER BY id DESC;

SELECT * FROM t_kooup_class_student csi WHERE csi.class_code in('CLS421322675999211520') ;

