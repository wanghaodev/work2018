SELECT
	id,
	class_code,
	class_name,
	class_status,
	class_order,
	lesson_number,
	course_code,
	outer_class_id,
	create_time,
	update_time,
	validation,
	create_user_code,
	update_user_code,
	student_number,
	effective_student_number,
	current_lesson_code
FROM
	t_kooup_class_info
WHERE
	validation = 1
AND outer_class_id = '195'