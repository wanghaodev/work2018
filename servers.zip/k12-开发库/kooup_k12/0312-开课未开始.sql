-- 未开始
SELECT
	temp.product_code,
	temp.start_time
FROM
	(
		SELECT
			MIN(live.start_time) start_time,
			MAX(live.end_time) end_time,
			live.product_code
		FROM
			t_kooup_live live
		WHERE
			live.product_code IS NOT NULL
		GROUP BY
			live.product_code
	) temp
WHERE
	temp.start_time > DATE_FORMAT('2018-03-12', '%Y-%m-%d');

-- 开课中 (第一节课开课时间小于当前时间，最后一节课结束时间大于当前时间)


SELECT
	temp.product_code,
	temp.start_time,
	temp.end_time
FROM
	(
		SELECT
			MIN(live.start_time) start_time,
			MAX(live.end_time) end_time,
			live.product_code
		FROM
			t_kooup_live live
		WHERE
			live.product_code IS NOT NULL
		GROUP BY
			live.product_code
	) temp
WHERE
	temp.start_time <= DATE_FORMAT('2018-03-12', '%Y-%m-%d') < temp.end_time;

-- 开课结束（最后一节课结束时间小于当前时间）


SELECT
	temp.product_code,
	temp.start_time,
	temp.end_time
FROM
	(
		SELECT
			MIN(live.start_time) start_time,
			MAX(live.end_time) end_time,
			live.product_code
		FROM
			t_kooup_live live
		WHERE
			live.product_code IS NOT NULL
		GROUP BY
			live.product_code
	) temp
WHERE
	temp.end_time <= DATE_FORMAT('2018-03-12', '%Y-%m-%d');