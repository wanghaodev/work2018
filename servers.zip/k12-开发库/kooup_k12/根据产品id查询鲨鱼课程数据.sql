SELECT DISTINCT
	SharksLiveGroup.id,
	SharksLiveGroup.live_type,
	SharksLiveGroup.service_id,
	SharksLiveGroup.is_deleted,
	SharksLiveGroup.`name`,
	SharksLiveGroup.subject_id,
	SharksLiveGroup.create_time,
	SharksLiveGroup.update_time,
	SharksLiveGroup.create_uid,
	SharksLiveGroup.update_uid,
	scheduleCourse.capacity
FROM
	t_sharks_live_group SharksLiveGroup
LEFT JOIN t_sharks_product_item sharksProductItem ON sharksProductItem.item_id = SharksLiveGroup.id
LEFT JOIN t_schedule_course scheduleCourse ON scheduleCourse.id = SharksLiveGroup.service_id
WHERE
	1 = 1
      AND sharksProductItem.product_id = 5960