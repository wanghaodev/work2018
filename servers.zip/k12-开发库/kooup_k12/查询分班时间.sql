SELECT
	*
FROM
	t_schedule_k12_course_extendinfo ScheduleK12CourseExtendinfo
WHERE
	ScheduleK12CourseExtendinfo.id = '19';

