-- 更新为未开始
UPDATE t_kooup_live live
SET live.live_status = 0
WHERE
	live.live_code IN (
		SELECT
			*
		FROM
			t_kooup_live live
		WHERE
			DATE_FORMAT('2018-03-12', '%Y%m%d') < live.start_time
	) 

-- 进行中
UPDATE t_kooup_live updatelive
SET updatelive.live_status = 1
WHERE
	updatelive.live_code IN (
SELECT
	live.live_code
FROM
	t_kooup_live live
WHERE
	DATE_FORMAT('2018-03-12 16:58', '%Y-%m-%d %H%i') 
BETWEEN DATE_FORMAT(live.start_time,'%Y-%m-%d %H:%i')
AND DATE_FORMAT(live.end_time,'%Y-%m-%d %H:%i')
	)

-- 已结束 
UPDATE t_kooup_live updatelive
SET updatelive.live_status = 2
WHERE
	updatelive.live_code IN (
		SELECT
			*
		FROM
			t_kooup_live live
		WHERE
			live.end_time < DATE_FORMAT('2018-03-12', '%Y%m%d')
	)