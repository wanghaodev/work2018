SELECT
courseExtendinfo.start_time
FROM
	t_kooup_class_info classInfo
LEFT JOIN t_kooup_lesson_info lessonInfo ON classInfo.class_code = lessonInfo.class_code
LEFT JOIN t_kooup_course_info courseInfo ON courseInfo.course_code = lessonInfo.course_code
LEFT JOIN t_schedule_k12_course_extendinfo  courseExtendinfo ON courseExtendinfo.course_id = courseInfo.service_id
WHERE classInfo.outer_class_id = ''


