SELECT
	ClassroomTeacher.teacher_code
FROM
	t_kooup_classroom_teacher ClassroomTeacher
WHERE
	ClassroomTeacher.id = '';

SELECT
	ClassroomLecturer.teacher_code
FROM
	t_kooup_classroom_lecturer ClassroomLecturer
WHERE
	ClassroomLecturer.id = '';

-- 直播课
SELECT
	kooupLive.live_code
FROM
	t_kooup_live kooupLive
WHERE
	kooupLive.outer_course_id = '';
-- 直播组
SELECT
	courseInfo.course_code
FROM
	t_kooup_course_info courseInfo
WHERE
	courseInfo.outer_course_id = '';

-- 班级编码
SELECT
	classInfo.class_code
FROM
	t_kooup_class_info classInfo
WHERE
	classInfo.outer_class_id = '';

-- 用户编码
SELECT sysUser.user_code FROM sys_user sysUser WHERE sysUser.outer_user_id = '';
