SELECT DISTINCT
	liveGroupRelationship.live_id,
	productInfo.product_code,
	productInfo.outer_product_id,
	liveGroup.outer_course_id,
	liveGroup.service_id
FROM
	t_kooup_product_info productInfo
LEFT JOIN t_sharks_product_item productItem ON productInfo.outer_product_id = productItem.product_id
LEFT JOIN t_kooup_course_info liveGroup ON liveGroup.outer_course_id = productItem.item_id
LEFT JOIN t_sharks_live_group_relationship liveGroupRelationship ON liveGroup.outer_course_id = liveGroupRelationship.live_group_id
WHERE
	1 = 1 
AND liveGroupRelationship.live_id = '10237';