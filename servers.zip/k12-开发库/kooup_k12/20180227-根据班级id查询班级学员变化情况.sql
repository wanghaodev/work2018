-- 根据班级id查询班级学员变化情况
SELECT ScheduleClassroom.id AS classroom_id,ScheduleOrder.student_id AS student_id  FROM t_schedule_classroom  ScheduleClassroom 
RIGHT  JOIN t_schedule_order_classroom_rel orderClassroomRel ON orderClassroomRel.classroom_id = ScheduleClassroom.id
LEFT JOIN t_schedule_order ScheduleOrder ON ScheduleOrder.id = orderClassroomRel.order_id
WHERE ScheduleClassroom.id = '198'
