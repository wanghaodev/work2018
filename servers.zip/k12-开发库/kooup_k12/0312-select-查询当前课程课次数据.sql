-- 查询当前课程课次数据 
SELECT
	lf.class_code,lf.course_code,lf.current,lf.lesson_status,lf.lesson_code,lf.lesson_order
FROM
	t_kooup_lesson_info lf
WHERE
	DATE_FORMAT(lf.start_time, '%Y-%m-%d %H:%i')=DATE_FORMAT('2018-03-12 07:00','%Y-%m-%d %H:%i')
-- AND lf.lesson_code = 'L420682674881953792'
