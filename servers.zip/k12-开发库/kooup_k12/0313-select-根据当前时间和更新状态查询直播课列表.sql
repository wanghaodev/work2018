-- (根据当前时间和更新状态查询直播课列表)
SELECT
		live.live_code
FROM
		t_kooup_live live
WHERE live.validation = 1
AND		DATE_FORMAT('2018-03-12 08:00', '%Y-%m-%d %H%i')
BETWEEN DATE_FORMAT(live.start_time,'%Y-%m-%d %H:%i')
AND DATE_FORMAT(live.end_time,'%Y-%m-%d %H:%i')