-- 课次插入数据查询
SELECT
        ScheduleLesson.id,
        ScheduleLesson.`subject`,
        ScheduleLesson.start_time,
        ScheduleLesson.end_time,
        live.live_status as state,
        classInfo.class_code,
        classroomteacher.teacher_code AS classroom_teacher_code,
        live.teacher_code AS  live_teacher_code,
        courseInfo.course_code,
        lessonLiveRel.live_id,
        lessonLiveRel.group_id,
        live.live_code,
        live.live_num
    FROM
        t_schedule_lesson ScheduleLesson
    LEFT JOIN t_schedule_lesson_live_rel lessonLiveRel ON ScheduleLesson.id = lessonLiveRel.lesson_id
    LEFT JOIN t_kooup_live live ON live.id = lessonLiveRel.live_id AND live.validation = 1 AND live.disuse = 1
    LEFT JOIN t_kooup_class_info classInfo ON classInfo.outer_class_id = ScheduleLesson.classroom_id
    LEFT JOIN t_kooup_course_info courseInfo ON courseInfo.outer_course_id = lessonLiveRel.group_id
    LEFT JOIN t_schedule_user scheduleUser ON scheduleUser.id = ScheduleLesson.teacher_id
    LEFT JOIN sys_user kooupUser ON kooupUser.outer_user_id = scheduleUser.sso_id
    LEFT JOIN t_kooup_classroom_teacher classroomteacher ON classroomteacher.user_code = kooupUser.user_code
      WHERE
      ScheduleLesson.id IN (381,382);
-- 
SELECT * FROM t_schedule_lesson_live_rel;

SELECT * FROM t_schedule_lesson;

SELECT * FROM t_kooup_classroom_teacher;
-- 排课系统学管老师
SELECT * FROM t_schedule_user scheduleUser ;
-- 179	67340972
-- 180	67341084

-- 67340968
-- 94	141

SELECT * FROM sys_user u;
--
SELECT * FROM t_schedule_lesson;

SELECT * FROM  t_kooup_class_info;

SELECT * FROM  t_kooup_lesson_info l where l.live_code =  'PL433602972052619264';

SELECT * FROM t_kooup_class_student;

SELECT * FROM t_kooup_lesson_student lt where lt.student_code = 'STU434026230396747776';

SELECT * FROM t_kooup_student stu where stu.student_code = 'STU434026230396747776';