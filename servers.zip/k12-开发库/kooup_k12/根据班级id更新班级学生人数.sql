UPDATE t_kooup_class_info cinfo
SET cinfo.student_number = (
	SELECT
		sum(1)
	FROM
		t_kooup_class_student stu
	WHERE
		stu.class_code = cinfo.class_code
) 

where  cinfo.outer_class_id = 207