SELECT
	user.photo AS userphoto,
	teacher.mobile,
	teacher.mail,
	teacher.work_account
FROM
	`sys_user` USER
LEFT JOIN t_kooup_classroom_teacher teacher ON teacher.teacher_name = USER .show_name
WHERE
	teacher.teacher_name LIKE '%2018020801%'