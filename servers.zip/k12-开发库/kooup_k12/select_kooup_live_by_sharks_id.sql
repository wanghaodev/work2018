 SELECT
            koouplive.id,
            koouplive.live_code,
            koouplive.live_name,
            koouplive.product_line,
            koouplive.exam_season_id,
            koouplive.vyear,
            koouplive.vquarter,
            koouplive.live_type,
            koouplive.start_time,
            koouplive.end_time,
            koouplive.subject_id,
            koouplive.outer_course_id,
            koouplive.product_code,
            koouplive.validation,
            koouplive.teacher_code
        FROM
            t_kooup_live koouplive
      WHERE koouplive.outer_course_id='6605'