SELECT * FROM t_kooup_mq_chanage_notify m WHERE m.is_new_flag = 1;

