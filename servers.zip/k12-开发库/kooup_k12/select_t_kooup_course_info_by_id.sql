SELECT
	sharksCourse.id,
	sharksCourse.course_code,
	sharksCourse.course_name,
	sharksCourse.course_status,
	sharksCourse.product_code,
	sharksCourse.subject_id,
	sharksCourse.create_time,
	sharksCourse.update_time,
	sharksCourse.validation,
	sharksCourse.carete_user_code,
	sharksCourse.update_user_code,
	sharksCourse.outer_course_id,
	sharksCourse.service_id
FROM
	t_kooup_course_info sharksCourse
WHERE
	sharksCourse.outer_course_id = '4752'