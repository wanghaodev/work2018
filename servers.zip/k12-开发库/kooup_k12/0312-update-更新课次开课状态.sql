-- 未开课
UPDATE t_kooup_product_info pf SET pf.product_course_status = 0
WHERE pf.product_code in(
SELECT DISTINCT
	temp.product_code
FROM
	(
		SELECT
			MIN(live.start_time) start_time,
			MAX(live.end_time) end_time,
			live.product_code
		FROM
			t_kooup_live live
		WHERE
			live.product_code IS NOT NULL
		GROUP BY
			live.product_code
	) temp
WHERE
	temp.start_time > DATE_FORMAT('2018-03-12', '%Y-%m-%d')
);

-- 进行中
UPDATE t_kooup_product_info pf SET pf.product_course_status = 1
WHERE pf.product_code in(
SELECT
	temp.product_code
FROM
	(
		SELECT
			MIN(live.start_time) start_time,
			MAX(live.end_time) end_time,
			live.product_code
		FROM
			t_kooup_live live
		WHERE
			live.product_code IS NOT NULL
		GROUP BY
			live.product_code
	) temp
WHERE
	temp.start_time <= DATE_FORMAT('2018-03-12', '%Y-%m-%d') < temp.end_time
)

-- 已结束
UPDATE t_kooup_product_info pf SET pf.product_course_status = 2
WHERE pf.product_code in(
SELECT
	temp.product_code
FROM
	(
		SELECT
			MIN(live.start_time) start_time,
			MAX(live.end_time) end_time,
			live.product_code
		FROM
			t_kooup_live live
		WHERE
			live.product_code IS NOT NULL
		GROUP BY
			live.product_code
	) temp
WHERE
	temp.end_time < DATE_FORMAT('2018-03-12', '%Y-%m-%d')
);


