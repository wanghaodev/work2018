-- 是否为当前课程
SELECT
		lf.class_code,lf.course_code,lf.current,lf.lesson_status,lf.lesson_code,lf.lesson_order
FROM
	t_kooup_lesson_info lf
WHERE
	DATE_FORMAT(lf.start_time, '%Y-%m-%d %H:%i')=DATE_FORMAT('2018-03-12 08:00','%Y-%m-%d %H:%i');

-- 当前已开课，并且为当前课次时，则将当前课次码修改为非当前课次，修改下一条记录
SELECT * FROM t_kooup_lesson_info lf WHERE lf.course_code = 'PC419090116787568640' AND lf.current=1 AND lf.lesson_status=1;