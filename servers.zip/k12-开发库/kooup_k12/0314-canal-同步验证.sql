SELECT * FROM t_sharks_product p WHERE p.`name` like  '%刘月娟%';

SELECT * FROM t_schedule_course c WHERE c.`name` like '%刘月娟服务%';

SELECT * from t_kooup_file fi where 
   fi.file_code in ('F421690343344308224','F420317514086481920','F420317697968963584');