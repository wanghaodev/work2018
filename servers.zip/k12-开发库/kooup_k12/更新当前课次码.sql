-- 将当前未开课的当前课次标识改为1
UPDATE t_kooup_lesson_info lf SET lf.current=1 WHERE  lf.lesson_status=0 AND lf.lesson_code = 'L420682674881953792';
-- 将当前已开课的当前课次标识改为0
UPDATE t_kooup_lesson_info lf SET lf.current=0 WHERE lf.current=1 AND lf.lesson_status=1 AND lf.course_code='';
