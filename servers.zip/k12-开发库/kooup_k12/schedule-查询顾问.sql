SELECT
	id,
	NAME,
	phone,
	email,
	avator,
	STATUS,
	remark,
	state,
	create_time,
	update_time,
	creator,
	new_flag
FROM
	t_schedule_consultant
WHERE
	id = 79