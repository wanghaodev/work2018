SELECT * FROM t_kooup_mq_chanage_notify m where m.is_new_flag = 1;
