 SELECT
        SysBaseDate.`CODE`AS subjectCode,
        SysBaseDate.`NAME` AS subjectName
    FROM
        sys_base_data SysBaseDate
WHERE
	SysBaseDate.TYPE = 'subject'
AND SysBaseDate.`NAME`='语文'