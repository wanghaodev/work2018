SELECT
	KooupClassTeacher.teacher_code,
	KooupClassTeacher.teacher_name,
	CourseTeacherRel.course_id AS service_id,
	KooupCourseInfo.course_code,
	KooupCourseInfo.course_name,
	KooupClassTeacher.carete_user_code,
	KooupClassTeacher.create_time,
	KooupClassTeacher.update_user_code,
	KooupClassTeacher.update_time
FROM
	t_kooup_classroom_teacher KooupClassTeacher 
	LEFT JOIN 
t_schedule_course_teacher_rel  CourseTeacherRel ON courseTeacherRel.teacher_id = KooupClassTeacher.id
LEFT JOIN 
t_kooup_course_info KooupCourseInfo  ON KooupCourseInfo.service_id = courseTeacherRel.course_id
WHERE KooupCourseInfo.service_id = '317' 
