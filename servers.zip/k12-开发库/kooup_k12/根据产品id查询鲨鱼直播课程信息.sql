SELECT
	SharksLiveGroup.id AS outer_course_id,
	SharksLiveGroup.live_type,
	SharksLiveGroup.service_id,
	SharksLiveGroup.is_deleted,
	SharksLiveGroup.`name`,
	SharksLiveGroup.subject_id,
	SharksLiveGroup.create_time,
	SharksLiveGroup.update_time,
	SharksLiveGroup.create_uid,
	SharksLiveGroup.update_uid
FROM
	t_sharks_live_group SharksLiveGroup
LEFT JOIN t_sharks_product_item sharksProductItem ON sharksProductItem.item_id = SharksLiveGroup.id
WHERE
	1 = 1
AND sharksProductItem.product_id = '8447'