SELECT
	lesson.id,
lesson.lesson_code,
	MIN(lesson.start_time) as current_start_time
FROM
	t_kooup_lesson_info lesson  LEFT JOIN t_kooup_class_info classInfo ON classInfo.class_code = lesson.class_code
WHERE lesson.lesson_status = 0
AND classInfo.outer_class_id = ''