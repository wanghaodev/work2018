-- 查看产品分班状态和直播课状态
SELECT p.product_disp_name,p.product_assign_status,p.product_course_status,p.vyear FROM t_kooup_product_info p WHERE  p.product_course_status = 2 AND p.product_assign_status=1;

-- 查询班级分班状态
SELECT cf.course_code,cf.class_name,cf.class_status FROM t_kooup_class_info cf WHERE cf.class_status = 0;

-- 查询课次状态情况和当期课次
SELECT * FROM t_kooup_lesson_info lf WHERE lf.lesson_status = '0' AND lf.course_code = 'PC421039421047963648'