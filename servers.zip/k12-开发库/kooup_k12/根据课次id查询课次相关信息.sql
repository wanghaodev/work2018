SELECT
	ScheduleLesson.id AS outer_lesson_id,
	ScheduleLesson.`subject`,
	ScheduleLesson.start_time,
	ScheduleLesson.end_time,
	ScheduleLesson.state,
	ScheduleLesson.classroom_id,
	ScheduleLesson.teacher_id classroom_teacher_id,
	lessonLiveRel.course_id,
	lessonLiveRel.group_id,
	lessonLiveRel.live_id,
	sharksLiveTeacher.teacher_id AS classroom_lecturer_id,
	sharksLive.disuse_reason
FROM
	t_schedule_lesson ScheduleLesson
LEFT JOIN t_schedule_lesson_live_rel lessonLiveRel ON ScheduleLesson.id = lessonLiveRel.lesson_id
LEFT JOIN t_sharks_live sharksLive ON sharksLive.id = lessonLiveRel.live_id
LEFT JOIN t_sharks_live_teacher sharksLiveTeacher ON sharksLiveTeacher.live_id = sharksLive.id