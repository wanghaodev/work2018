
SELECT
	lesson.lesson_code,lesson.course_code,lesson.lesson_order,lesson.class_code
FROM
	t_kooup_lesson_info lesson
WHERE
	lesson.validation = 1
AND lesson.lesson_status = 0
AND lesson.disuse = 1
AND lesson.course_code = 'PC427616440414109696'
ORDER BY lesson.start_time
LIMIT 1